# SocialVibe Production Scaffold
Includes auth, feed, profiles, comments, likes, follows, and Supabase structure.