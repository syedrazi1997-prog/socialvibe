
create table profiles(id uuid primary key, username text unique);
create table videos(id uuid primary key, user_id uuid, title text, video_url text);
create table comments(id uuid primary key, video_id uuid, user_id uuid, content text);
create table likes(id uuid primary key, video_id uuid, user_id uuid);
create table follows(id uuid primary key, follower_id uuid, following_id uuid);
